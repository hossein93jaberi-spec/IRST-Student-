import express from "express";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json({ limit: "8mb" }));

const PORT = process.env.PORT || 3000;
const AI_API_URL = process.env.AI_API_URL;
const AI_API_KEY = process.env.AI_API_KEY;
const AI_MODEL = process.env.AI_MODEL || "gpt-4.1-mini";

app.get("/health", (_req, res) => res.json({ ok: true, service: "IRST Student API" }));

app.post("/api/ai/ask", async (req, res) => {
  try {
    const question = String(req.body?.question || "").trim();
    if (!question) return res.status(400).json({ error: "سؤال خالی است." });
    if (!AI_API_URL || !AI_API_KEY) {
      return res.status(503).json({ error: "سرویس هوش مصنوعی هنوز توسط مدیر سامانه تنظیم نشده است." });
    }
    const upstream = await fetch(AI_API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${AI_API_KEY}`
      },
      body: JSON.stringify({
        model: AI_MODEL,
        messages: [
          { role: "system", content: "تو دستیار آموزشی فارسی برای دانش‌آموزان ایرانی هستی. پاسخ‌ها را دقیق، امن، متناسب با سن و مرحله‌به‌مرحله بده. به جای انجام کورکورانه تکلیف، روش حل را آموزش بده." },
          { role: "user", content: question }
        ]
      })
    });
    const data = await upstream.json();
    if (!upstream.ok) return res.status(502).json({ error: "خطا از سرویس هوش مصنوعی", detail: data });
    const answer = data.choices?.[0]?.message?.content || "پاسخی دریافت نشد.";
    res.json({ answer });
  } catch {
    res.status(500).json({ error: "خطای داخلی سرور." });
  }
});

app.listen(PORT, () => console.log(`IRST API listening on ${PORT}`));

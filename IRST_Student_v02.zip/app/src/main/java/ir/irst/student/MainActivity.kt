package ir.irst.student

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.InputType
import android.graphics.Color
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private var gender = ""
    private var themeName = ""
    private var accent = Color.rgb(40, 100, 190)
    private val prefs by lazy { getSharedPreferences("irst", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showWelcome()
    }

    private fun setup(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 20, 22, 20)
            setBackgroundColor(Color.rgb(247, 249, 252))
        }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
        val header = TextView(this).apply {
            text = "⚔️                         irst                         فروهر\n$title"
            textSize = 21f
            setTextColor(Color.rgb(25, 40, 65))
            gravity = Gravity.CENTER
            setTypeface(null, Typeface.BOLD)
            setPadding(4, 12, 4, 24)
        }
        root.addView(header)
    }

    private fun button(label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            textSize = 16f
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                cornerRadius = 24f
                setColor(accent)
            }
            setPadding(8, 12, 8, 12)
            setOnClickListener { action() }
        }
        root.addView(b, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 7, 0, 7) })
    }

    private fun label(text: String, size: Float = 17f) {
        root.addView(TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(Color.rgb(35, 45, 60))
            setPadding(4, 10, 4, 10)
        })
    }

    private fun field(hint: String, password: Boolean = false): EditText {
        val e = EditText(this).apply {
            this.hint = hint
            textSize = 16f
            setSingleLine(true)
            if (password) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        root.addView(e, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 5, 0, 5) })
        return e
    }

    private fun showWelcome() {
        setup("به IRST Student خوش آمدی")
        label("سامانه هوشمند دانش‌آموزان ایرانی", 19f)
        label("برای شروع، خودت را معرفی کن.")
        button("شروع") { showGender() }
    }

    private fun showGender() {
        setup("انتخاب دانش‌آموز")
        label("دانش‌آموز دختر هستی یا پسر؟")
        button("پسر") { gender = "پسر"; showBoysTheme() }
        button("دختر") { gender = "دختر"; showGirlsTheme() }
    }

    private fun showBoysTheme() {
        setup("تیم مورد علاقه")
        label("تیم مورد علاقه‌ات را انتخاب کن:")
        val teams = listOf(
            Triple("تراکتور", Color.rgb(205, 25, 45), Color.WHITE),
            Triple("سپاهان", Color.rgb(245, 195, 20), Color.BLACK),
            Triple("استقلال", Color.rgb(30, 105, 205), Color.WHITE),
            Triple("پرسپولیس", Color.rgb(190, 25, 45), Color.BLACK)
        )
        teams.forEach { (name, c, _) ->
            button(name) { themeName = name; accent = c; showAccount() }
        }
    }

    private fun showGirlsTheme() {
        setup("شخصیت مورد علاقه")
        label("کدام شخصیت را دوست داری؟")
        val choices = listOf(
            Triple("رومی", Color.rgb(105, 55, 145), "بنفش و مشکی"),
            Triple("کرومی", Color.rgb(40, 25, 55), "مشکی و بنفش"),
            Triple("کیتی", Color.rgb(235, 130, 165), "صورتی و سفید"),
            Triple("هیچ‌کدام", Color.rgb(35, 35, 40), "مشکی و سفید")
        )
        choices.forEach { (name, c, _) ->
            button(name) { themeName = name; accent = c; showAccount() }
        }
    }

    private fun showAccount() {
        setup("ساخت حساب کاربری")
        label("نام کاربری و رمز عبور انتخاب کن.")
        val username = field("نام کاربری")
        val pass = field("رمز عبور", true)
        val confirm = field("تکرار رمز عبور", true)
        button("ایجاد حساب و ادامه") {
            val u = username.text.toString().trim()
            val p = pass.text.toString()
            if (u.length < 3 || p.length < 6 || p != confirm.text.toString()) {
                toast("نام کاربری حداقل ۳ و رمز حداقل ۶ نویسه باشد و رمزها یکسان باشند.")
            } else {
                // Prototype only: credentials are stored locally, not on a secure online server.
                prefs.edit().putString("username", u)
                    .putString("gender", gender).putString("theme", themeName).apply()
                showHome()
            }
        }
        label("توجه: این نسخه نمونه است؛ حساب آنلاین و همگام‌سازی والدین هنوز راه‌اندازی نشده است.", 13f)
    }

    private fun showHome() {
        setup("خانه | ${prefs.getString("username", "")}")
        label("تم انتخابی: $themeName")
        label("به IRST Student خوش آمدی. از بخش‌های زیر استفاده کن:")
        button("📅 برنامه‌ریزی روزانه و هفتگی") { showPlanner() }
        button("🤖 هوش مصنوعی درسی") { showAI() }
        button("📚 پرونده درسی و امتحانات") { showSchool() }
        button("👤 شخصی‌سازی حساب") { showProfile() }
    }


    private fun showPlanner() {
        setup("برنامه‌ریز ۲۴ ساعته")
        label("روز و ساعت را انتخاب کن و هر تعداد فعالیت خواستی اضافه کن.")
        val days = listOf("شنبه","یکشنبه","دوشنبه","سه‌شنبه","چهارشنبه","پنجشنبه","جمعه")
        val day = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, days)
        }
        root.addView(day)
        val start = field("ساعت شروع (مثلاً 15:00)")
        val end = field("ساعت پایان (مثلاً 16:00)")
        val activity = field("نام فعالیت")
        val list = TextView(this).apply { textSize = 15f; setTextColor(Color.DKGRAY) }
        fun refresh() {
            val saved = prefs.getString("planner_${day.selectedItem}", "") ?: ""
            list.text = if (saved.isBlank()) "برای این روز هنوز فعالیتی ثبت نشده." else saved.replace("||", "\n\n")
        }
        day.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) = refresh()
        }
        button("＋ افزودن فعالیت") {
            val s = start.text.toString().trim()
            val e = end.text.toString().trim()
            val a = activity.text.toString().trim()
            if (!validTime(s) || !validTime(e) || a.isEmpty()) {
                toast("ساعت معتبر و نام فعالیت را وارد کن.")
            } else {
                val key = "planner_${day.selectedItem}"
                val current = prefs.getString(key, "") ?: ""
                val item = "$s تا $e — $a"
                val updated = if (current.isBlank()) item else "$current||$item"
                prefs.edit().putString(key, updated).apply()
                activity.setText("")
                refresh()
            }
        }
        button("🗑 پاک کردن برنامه همین روز") {
            prefs.edit().remove("planner_${day.selectedItem}").apply()
            refresh()
        }
        root.addView(list)
        refresh()
        button("بازگشت به خانه") { showHome() }
    }

    private fun validTime(t: String): Boolean = Regex("^([01]?[0-9]|2[0-3]):[0-5][0-9]$").matches(t)


    private fun showAI() {
        setup("هوش مصنوعی درسی")
        label("سؤالت را بنویس. برای پاسخ واقعی باید سرور IRST راه‌اندازی و آدرس آن تنظیم شود.")
        val question = field("مثلاً کسرها را ساده توضیح بده...")
        val answer = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.rgb(35, 45, 60))
            setPadding(8, 18, 8, 18)
            text = "پاسخ هوش مصنوعی اینجا نمایش داده می‌شود."
        }
        button("ارسال سؤال") {
            if (question.text.toString().trim().isEmpty()) {
                toast("اول سؤالت را بنویس.")
            } else {
                answer.text = "اتصال سرور هنوز تنظیم نشده است. در پوشه backend راهنمای راه‌اندازی وجود دارد. کلید محرمانه هوش مصنوعی باید فقط روی سرور قرار بگیرد، نه داخل برنامه."
            }
        }
        root.addView(answer)
        button("بازگشت به خانه") { showHome() }
    }

    private fun showSchool() {
        setup("پرونده درسی و امتحانات")
        label("در نسخه بعدی: ثبت درس‌ها، برنامه مدرسه، عکس برگه امتحان، نمره و تحلیل اشتباهات.")
        button("بازگشت به خانه") { showHome() }
    }

    private fun showProfile() {
        setup("شخصی‌سازی حساب")
        label("نام کاربری: ${prefs.getString("username", "")}")
        label("جنسیت انتخاب‌شده: $gender")
        label("انتخاب فعلی: $themeName")
        button("خروج از حساب") {
            prefs.edit().clear().apply()
            showWelcome()
        }
        button("بازگشت به خانه") { showHome() }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
